#!/bin/bash

  echo "[ ] Start vagrant provisioning"

  # Add Docker's official GPG key:
  sudo apt update && sudo apt upgrade -y && sudo apt autoremove –y
  sudo apt --fix-broken install -y
  sudo apt-get install ca-certificates curl -y  
  sudo apt-get install openssh-server -y
  sudo apt-get install wget tree -y
  sudo apt install \
  apparmor \
  cifs-utils \
  curl \
  dbus \
  jq \
  libglib2.0-bin \
  lsb-release \
  network-manager \
  nfs-common \
  udisks2 \
  wget -y
  
  sudo curl -fsSL https://download.docker.com/linux/debian/gpg -o /etc/apt/keyrings/docker.asc
  sudo chmod a+r /etc/apt/keyrings/docker.asc

  # Add the repository to Apt sources:
  echo "[ ] install docker "
  echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/debian \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null 
  sudo apt update -y
  sudo apt-get install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin -y 
  sudo usermod -aG docker vagrant 
  newgrp docker
 
