#include "LiquidCrystal_I2C.h"
#include "RTClib.h"
#include <Arduino.h>
#include <TimeLib.h> // https://github.com/PaulStoffregen/Time
#include <Wire.h>


extern RTC_DS3231 rtc;
LiquidCrystal_I2C lcd(0x27, 20, 4);

const char ap_ssid[] = "KMM";

// Prototype
void initLcd();
void welcome();
void writeLCDLine(int line, String message);
uint32_t getchipid();
void printFrame();
void createCustomCharacters();

// Function
void connectSim() {
  lcd.begin();
  lcd.setCursor(0, 0); //
  lcd.print("Try AIS 4G Sim");
  lcd.setCursor(0, 1); //
  lcd.print("Please wait 15 s");
}

void connectSuccess() {
  // lcd.begin();
  lcd.setCursor(0, 2); //
  lcd.print("4G Net Ok");
}

void showcsq(int csq) {
  // lcd.begin();
  lcd.setCursor(10, 2);
  lcd.print(", CSQ: ");
  lcd.setCursor(16, 2);
  lcd.print(csq);
}

void showip(String ip) {
  lcd.setCursor(0, 3);
  lcd.print("IP : ");
  lcd.setCursor(4, 3);
  lcd.print(ip);
}

void connectFail() {
  lcd.setCursor(0, 2); //
  lcd.print("Internet Fail ..");
}

void connectmagelsuccess() {
  lcd.setCursor(0, 3); //
  lcd.print("Magel Ready (OK)");

}

void connectmagelfail() {
  lcd.setCursor(0, 3); //
  lcd.print("Connect Magel Fail ..");
}
// Function

// Function
void autoconfiglcd() {
  byte error, address;

  Serial.println("## 1 Scanning i2c Address ...");

  for (address = 1; address < 127; address++) {
    Wire.beginTransmission(address);
    error = Wire.endTransmission();

    if (error == 0) {
      Serial.print("### Device found at address 0x");
      if (address < 16)
        Serial.print("0");
      Serial.print(address, HEX);
      Serial.println("");

      if (address == 0x27) {
        Serial.println("---- Set LCD Address to 0x27");
        lcd = LiquidCrystal_I2C(address, 20, 4);
        // Additional configuration if needed for address 0x27
      } else if (address == 0x3F) {
        Serial.println("---- Set LCD Address to 0x3f");
        lcd = LiquidCrystal_I2C(address, 20, 4);
        // Additional configuration if needed for address 0x3F
      }
    } else if (error == 4) {
      Serial.print("### Unknown error at address 0x");
      if (address < 16)
        Serial.print("0");
      Serial.println(address, HEX);
    }
  }

  delay(5000); // Wait 5 seconds for the next scan
}

void initLcd() {
  lcd.begin();
  lcd.backlight();
  lcd.clear();
  welcome();
}

void clearLCDLine(int line) {
  lcd.setCursor(0, line);
  for (int n = 0; n < 20;
       n++) // 20 indicates symbols in line. For 2x16 LCD write - 16
  {
    lcd.print(" ");
  }
}

void writeLCDLine(int line, String message) {
  clearLCDLine(line);
  lcd.setCursor(0, line); //
  lcd.print(message);
}

String msg[] = {"<< Start System >>", "Connect to Magellan",
                "KomomiFarm Training"};

void welcome() {
  lcd.begin();
  lcd.setCursor(0, 0); //
  lcd.print(msg[0]);
  vTaskDelay(3000);
  lcd.setCursor(0, 0); //
  writeLCDLine(0, msg[2]);
  lcd.setCursor(0, 1); //
  lcd.print(msg[1]);
  char ap[20];
  // chipid
  // sprintf(ap, "Device: %s_%u", ap_ssid, getchipid());
  // training
  Serial.print("thingIdentifier : ");
  Serial.println(thingIdentifier.substring(14));
  String no = thingIdentifier.substring(14);
  sprintf(ap, "No : %s_%s", ap_ssid, no);
  writeLCDLine(2, ap);
}

uint32_t getchipid() {
  uint32_t chip_id = 0;
  for (int i = 0; i < 17; i = i + 8) {
    chip_id |= ((ESP.getEfuseMac() >> (40 - i)) & 0xff) << i;
  }
  return chip_id;
}

byte airsensoricon[] = {B01110, B01010, B01010, B01010,
                        B01010, B01110, B11111, B11111};

byte soilsensoricon[] = {B00100, B11111, B11111, B01010,
                         B01010, B01010, B11111, B01010};

byte celsiusicon[] = {B11100, B10100, B11100, B00011,
                      B00100, B00100, B00100, B00011};

byte heartBeaticon[] = {B00000, B00000, B11011, B01010,
                        B01010, B01010, B01010, B01110};

byte doticon[] = {B01100, B10010, B10010, B01100,
                  B00000, B00000, B00000, B00000};

byte controlicon[] = {B01110, B10001, B01110, B10101,
                      B00100, B11111, B01110, B01110};

byte lighticon[] = {B00000, B00100, B10101, B01110,
                    B11011, B01110, B10101, B00100};

byte moonicon[] = {B00000, B01100, B00110, B00111,
                   B00111, B00111, B00110, B01100};

void setupLcdIcon() {
  lcd.createChar(0, soilsensoricon);
  lcd.createChar(1, celsiusicon);
  lcd.createChar(2, airsensoricon);
  lcd.createChar(3, heartBeaticon);
  lcd.createChar(4, doticon);
  lcd.createChar(5, controlicon);
  lcd.createChar(6, lighticon);
  lcd.createChar(7, moonicon);
}

void iconTemp() {
  lcd.setCursor(0, 1);
  lcd.write(0);
  lcd.setCursor(1, 1);
  lcd.write(1);
  lcd.createChar(4, doticon);
  lcd.setCursor(8, 1);
  // lcd.write(4);
}

void iconHumid() {
  lcd.setCursor(10, 1);
  lcd.write(0);
  lcd.setCursor(11, 1);
  lcd.print("%");
}

void iconAir() {
  lcd.setCursor(0, 2);
  lcd.write(2);
  lcd.setCursor(1, 2);
  lcd.write(1);
  lcd.setCursor(10, 2);
  lcd.write(2);
  lcd.setCursor(11, 2);
  lcd.print("%");
}

void iconLight() {
  clearLCDLine(3);
  lcd.setCursor(0, 3);
  lcd.write(6);
  lcd.setCursor(1, 3);
  lcd.write(7);
  lcd.setCursor(10, 3);
  lcd.print("Lux");
}

void iconheartbeat() {
  lcd.setCursor(17, 3);
  lcd.write(3);
  lcd.setCursor(18, 3);
  lcd.write(3);
  lcd.setCursor(19, 3);
  lcd.write(3);
}

void cleariconheartbeat() {

  for (int i = 17; i < 20; i++) {
    lcd.setCursor(i, 3);
    lcd.print("");
  }
}

void showLedData(int colume, int line, float number) {
  lcd.setCursor(colume, line);
  lcd.print(number);
}

void lcd_showtime() {
  Serial.println("6 lcd show time");
  char datebuf[64];
  char timebuf[64];
  DateTime now = rtc.now();
  sprintf(datebuf, "%02d:%02d:%02d", now.hour(), now.minute(), now.second());
  sprintf(timebuf, "%02d/%02d/%02d", now.day(), now.month(), now.year());
  lcd.begin();
  lcd.clear();
  lcd.setCursor(5, 1);
  lcd.print(timebuf);

  lcd.setCursor(6, 2);
  lcd.print(datebuf);
  delay(1000);
}

void lcd_sensordisplay() {}
void lcd_showcontrol() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.write(5);
  lcd.setCursor(2, 0);
  lcd.print("Control Status");
  lcd.setCursor(0, 1);
  lcd.print("Pump  ");

  lcd.setCursor(7, 1);
  if (pump_status == 1) {
    lcd.print("ON");
  } else {
    lcd.print("OFF");
  }

  lcd.setCursor(11, 1);
  lcd.print("Zone1 ");

  lcd.setCursor(17, 1);
  if (zone1_status == 1) {
    lcd.print("ON");
  } else {
    lcd.print("OFF");
  }

  lcd.setCursor(0, 2);
  lcd.print("Zone2  ");

  lcd.setCursor(7, 2);
  if (zone2_status == 1) {
    lcd.print("ON");
  } else {
    lcd.print("OFF");
  }

  lcd.setCursor(11, 2);
  lcd.print("Zone3 ");
  //
  lcd.setCursor(17, 2);
  if (zone3_status == 1) {
    lcd.print("ON");
  } else {
    lcd.print("OFF");
  }
  delay(2000);
}