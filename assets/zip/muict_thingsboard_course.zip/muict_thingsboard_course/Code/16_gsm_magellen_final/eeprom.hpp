#ifndef EEPROM_H
#define EEPROM_H

/*

   https://github.com/cyberp/AT24Cx/
   I2C device found at address 0x50 (EEPROM AT24C64D-SSHM-T-T) 64k
AT24Cx I2C adress
80
0x50
#define AT24CX_ID B1010000  <-- default address
*/

#include <Arduino.h>
#include <Wire.h>
#include <AT24CX.h>

// EEPROM object
AT24C64 mem;

#define RELAY1_MEM  1
#define RELAY2_MEM  2
#define RELAY3_MEM  3
#define RELAY4_MEM  4

#endif 