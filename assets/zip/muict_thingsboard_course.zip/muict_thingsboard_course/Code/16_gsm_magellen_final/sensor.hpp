
#include "SoilTemp.hpp"
#include "LightDFRobot.hpp"
#include "sht31.hpp"

float SoilHumidData = 0;
float SoilTempData = 0;
int Light = 0;
SoilTemp node3(3, "node3", &SerialSensor, 1.0f);

void getData()
{
    node3.init();
    // node3.getString();
    SoilHumidData = node3.getSoilHumid();
    SoilTempData = node3.getSoilTemp();
}