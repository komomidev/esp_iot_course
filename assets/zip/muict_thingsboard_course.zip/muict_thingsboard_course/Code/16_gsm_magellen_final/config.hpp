int pump_status = 0;
int zone1_status = 0;
int zone2_status = 0;
int zone3_status = 0;

#define RXD1 26
#define TXD1 25

#define RXD2 16
#define TXD2 17

#define HEARTBEAT 12
#define BUZZER 33
#define MODEM_POWER_ON 4
#define MODEM_KEY_ON 13
#define MODEM_STATUS 36
#define GSM_485_SELECTOR 14 // 0 = gsm , 1 485

const char apn[] = "internet";
const char gprsUser[] = "";
const char gprsPass[] = "";

// Add your magellen Broker IP address
String thingIdentifier = "7765032200000000000";
String thingSecret = "7765032200000000000";
String endpoint = "device-entmagellan.ais.co.th";

unsigned long magel_previousMillis = 0;
unsigned long magel_interval = 30000;
unsigned long data_previousMillis = 0;
unsigned long data_interval = 60000;
// Register String
String RLY1_name = "Pump";
String RLY2_name = "valve1";
String RLY3_name = "valve2";
String RLY4_name = "valve3";

int LED_BUILTIN = 2;
#define POWER_ON_SENSER 15 // GPIO15