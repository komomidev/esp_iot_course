#include <Adafruit_MCP23X17.h>
#include <Arduino.h>
#include <Wire.h>
#include <ArduinoJson.h>


StaticJsonDocument<1024> pinState;

// MCP23017 registers (everything except direction defaults to 0)
#define IODIRA 0x00 // IO direction  (0 = output, 1 = input (Default))
#define IODIRB 0x01
#define IOPOLA 0x02 // IO polarity   (0 = normal, 1 = inverse)
#define IOPOLB 0x03
#define GPINTENA 0x04 // Interrupt on change (0 = disable, 1 = enable)
#define GPINTENB 0x05
#define DEFVALA                                                                \
  0x06 // Default comparison for interrupt on change (interrupts on opposite)
#define DEFVALB 0x07
#define INTCONA                                                                \
  0x08 // Interrupt control (0 = interrupt on change from previous, 1 =
       // interrupt on change from DEFVAL)
#define INTCONB 0x09
#define IOCON                                                                  \
  0x0A // IO Configuration: bank/mirror/seqop/disslw/haen/odr/intpol/notimp
// #define IOCON 0x0B  // same as 0x0A
#define GPPUA 0x0C // Pull-up resistor (0 = disabled, 1 = enabled)
#define GPPUB 0x0D
#define INFTFA                                                                 \
  0x0E // Interrupt flag (read only) : (0 = no interrupt, 1 = pin caused
       // interrupt)
#define INFTFB 0x0F
#define INTCAPA                                                                \
  0x10 // Interrupt capture (read only) : value of GPIO at time of last
       // interrupt
#define INTCAPB 0x11
#define GPIOA 0x12 // Port value. Write to change, read to obtain value
#define GPIOB 0x13
#define OLLATA 0x14 // Output latch. Write to latch output.
#define OLLATB 0x15

// Define pin port A Output
byte mcp_pin_PA0 = 0; // Relay1
byte mcp_pin_PA1 = 1; // Relay2
byte mcp_pin_PA2 = 2; // Relay3
byte mcp_pin_PA3 = 3; // Relay4
byte mcp_pin_PA4 = 4; // LED3
byte mcp_pin_PA5 = 5; // LED2
byte mcp_pin_PA6 = 6; // LED4G
byte mcp_pin_PA7 = 7; // LEDWIFI

// Define pin port B input
byte mcp_pin_PB0 = 8;
byte mcp_pin_PB1 = 9;
byte mcp_pin_PB2 = 10;
byte mcp_pin_PB3 = 11;
byte mcp_pin_PB4 = 12;
byte mcp_pin_PB5 = 13;
byte mcp_pin_PB6 = 14;
byte mcp_pin_PB7 = 15;

volatile boolean awakenByInterrupt = false;

// active low
#define OFF 1
#define ON 0
// interupt pin
#define ISR_INDICATOR 34 // pin 34
#define mcp_address 0x20
#define ISR_PIN 34 // gpio 34

// Define macro
#define RELAY1_ON mcp0.digitalWrite(mcp_pin_PA0, ON)
#define RELAY2_ON mcp0.digitalWrite(mcp_pin_PA1, ON)
#define RELAY3_ON mcp0.digitalWrite(mcp_pin_PA2, ON)
#define RELAY4_ON mcp0.digitalWrite(mcp_pin_PA3, ON)
#define LED3_ON mcp0.digitalWrite(mcp_pin_PA4, ON)
#define LED2_ON mcp0.digitalWrite(mcp_pin_PA5, ON)
#define LED4G_ON mcp0.digitalWrite(mcp_pin_PA6, ON)
#define LEDWIFI_ON mcp0.digitalWrite(mcp_pin_PA7, ON)

#define RELAY1_OFF mcp0.digitalWrite(mcp_pin_PA0, OFF)
#define RELAY2_OFF mcp0.digitalWrite(mcp_pin_PA1, OFF)
#define RELAY3_OFF mcp0.digitalWrite(mcp_pin_PA2, OFF)
#define RELAY4_OFF mcp0.digitalWrite(mcp_pin_PA3, OFF)
#define LED3_OFF mcp0.digitalWrite(mcp_pin_PA4, OFF)
#define LED2_OFF mcp0.digitalWrite(mcp_pin_PA5, OFF)
#define LED4G_OFF mcp0.digitalWrite(mcp_pin_PA6, OFF)
#define LEDWIFI_OFF mcp0.digitalWrite(mcp_pin_PA7, OFF)

// input state input
int PUMPSTATE = 0;
int ZONE1STATE = 0;
int ZONE2STATE = 0;
int ZONE3STATE = 0;
int SW1STATE = 0;
int SW2STATE = 0;
int SW3STATE = 0;
int SW4STATE = 0;

int SW1PIN = 12;
int SW2PIN = 13;
int SW3PIN = 14;
int SW4PIN = 15;

// mcp object
Adafruit_MCP23X17 mcp0; // address x20

// Prototype
void mcp0_begin();
void expanderWriteBoth(const byte reg, const byte data);
void expanderWriteSingle(const byte reg, const byte data);
void IRAM_ATTR intCallBack();
void cleanInterrupts();
void handleInterrupt();
void readMCP0State();
void test_Relay();
void debugMcpInput();
int getBit(uint16_t data, int position);

// Function
void mcp0_begin() {
  Serial.println("5 MCP23017 Setup mcp0  0x20");
  expanderWriteSingle(GPINTENA, 0xFF);
  expanderWriteSingle(GPINTENB, 0xFF);

  // mcp.begin();
  if (!mcp0.begin_I2C(mcp_address)) {
    Serial.println("Error mcp.begin_I2C");
    while (1)
      ;
  }

  mcp0.setupInterrupts(false, true, LOW);
  // port A ouput
  for (byte i = 0; i < 8; i++) {
    mcp0.pinMode(i, OUTPUT);
    mcp0.digitalWrite(i, OFF);
  }
  // port B input
  for (byte i = 8; i < 16; i++) {
    mcp0.pinMode(i, INPUT);
    mcp0.setupInterruptPin(i, CHANGE);
  }
  mcp0.readGPIOAB();
} // end of mcp0

// i2c write reg 32 bit
void expanderWriteBoth(const byte reg, const byte data) {
  Wire.beginTransmission(mcp_address);
  Wire.write(reg);
  Wire.write(data); // port A
  Wire.write(data); // port B
  Wire.endTransmission();
} // end of expanderWrite

// i2c write reg 16 bit
void expanderWriteSingle(const byte reg, const byte data) {
  Wire.beginTransmission(mcp_address);
  Wire.write(reg);
  Wire.write(data); // port
  Wire.endTransmission();
}

// Interupt Callback function
void IRAM_ATTR intCallBack() { awakenByInterrupt = true; }

void cleanInterrupts() {
  delay(50);
  mcp0.readGPIOAB();
  mcp0.clearInterrupts();
  awakenByInterrupt = false;
}

void handleInterrupt() {
  uint8_t pin = mcp0.getLastInterruptPin();
  uint16_t data = mcp0.getCapturedInterrupt();
  Serial.println();
  Serial.println("## Handle Interrupts on MCP ");
  Serial.print("pin : ");
  Serial.print(pin);
  Serial.print(" , GPA0-7 GPB0-7 L->M bit 0-15 : ");
  for (int i = 0; i < 16; i++) {
    Serial.write((data >> i) & 1 ? '1' : '0');
  }
  Serial.println();
  // Read bit
  PUMPSTATE = getBit(data, 8);
  ZONE1STATE = getBit(data, 9);
  ZONE2STATE = getBit(data, 10);
  ZONE3STATE = getBit(data, 11);
  SW1STATE = getBit(data, 12);
  SW2STATE = getBit(data, 13);
  SW3STATE = getBit(data, 14);
  SW4STATE = getBit(data, 15);
  // Serial.println("### Report Manual update valve ");
  // if (!PUMPSTATE) {
  //   magelclient.sensor.add("Pump",1);
  // } else {
  //   magelclient.sensor.add("Pump", 0);
  // }
  // if (!ZONE1STATE) {
  //   magelclient.sensor.add("valve1", 1);
  // } else {
  //   magelclient.sensor.add("valve1", 0);
  // }
  // if (!ZONE2STATE) {
  //   magelclient.sensor.add("valve2", 1);
  // } else {
  //   magelclient.sensor.add("valve2", 0);
  // }
  // if (!ZONE3STATE) {
  //   magelclient.sensor.add("valve3", 1);
  // } else {
  //   magelclient.sensor.add("valve3", 0);
  // }
  
  // magelclient.sensor.report();
  
  Serial.println("## action Open Relay when press switch");
  if (pin == SW1PIN) {
    if (!SW1STATE) {
      RELAY1_ON;
    } else {
      RELAY1_OFF;
    }
  }
  // action
  if (pin == SW2PIN) {
    if (!SW2STATE) {
      RELAY2_ON;
    } else {
      RELAY2_OFF;
    }
  }
  // action
  if (pin == SW3PIN) {
    if (!SW3STATE) {
      RELAY3_ON;
    } else {
      RELAY3_OFF;
    }
  }

  // action
  if (pin == SW4PIN) {
    if (!SW4STATE) {
      RELAY4_ON;
    } else {
      RELAY4_OFF;
    }
  }

  debugMcpInput();
  cleanInterrupts();
}

// Extract bit value from position
int getBit(uint16_t data, int position) {
  return (data >> position) & 1 ? 1 : 0;
}

void debugMcpInput() {
  Serial.print(" PUMPSTATE :");
  Serial.println(PUMPSTATE);
  Serial.print(" ZONE1STATE :");
  Serial.println(ZONE1STATE);
  Serial.print(" ZONE2STATE :");
  Serial.println(ZONE2STATE);
  Serial.print(" ZONE3STATE :");
  Serial.println(ZONE3STATE);
  Serial.print(" SW1STATE :");
  Serial.println(SW1STATE);
  Serial.print(" SW2STATE :");
  Serial.println(SW2STATE);
  Serial.print(" SW3STATE :");
  Serial.println(SW3STATE);
  Serial.print(" SW4STATE :");
  Serial.println(SW4STATE);
}
void readMCP0State() {
  int PA0_state = mcp0.digitalRead(mcp_pin_PA0);
  int PA1_state = mcp0.digitalRead(mcp_pin_PA1);
  int PA2_state = mcp0.digitalRead(mcp_pin_PA2);
  int PA3_state = mcp0.digitalRead(mcp_pin_PA3);
  int PA4_state = mcp0.digitalRead(mcp_pin_PA4);
  int PA5_state = mcp0.digitalRead(mcp_pin_PA5);
  int PA6_state = mcp0.digitalRead(mcp_pin_PA6);
  int PA7_state = mcp0.digitalRead(mcp_pin_PA7);
  int PB0_state = mcp0.digitalRead(mcp_pin_PB0);
  int PB1_state = mcp0.digitalRead(mcp_pin_PB1);
  int PB2_state = mcp0.digitalRead(mcp_pin_PB2);
  int PB3_state = mcp0.digitalRead(mcp_pin_PB3);
  int PB4_state = mcp0.digitalRead(mcp_pin_PB4);
  int PB5_state = mcp0.digitalRead(mcp_pin_PB5);
  int PB6_state = mcp0.digitalRead(mcp_pin_PB6);
  int PB7_state = mcp0.digitalRead(mcp_pin_PB7);
  // output
  pinState["PA7"] = PA7_state;
  pinState["PA6"] = PA6_state;
  pinState["PA5"] = PA5_state;
  pinState["PA4"] = PA4_state;
  pinState["PA3"] = PA3_state;
  pinState["PA2"] = PA2_state;
  pinState["PA1"] = PA1_state;
  pinState["PA0"] = PA0_state;
  // input
  pinState["PB7"] = PB7_state;
  pinState["PB6"] = PB6_state;
  pinState["PB5"] = PB5_state;
  pinState["PB4"] = PB4_state;
  pinState["PB3"] = PB3_state;
  pinState["PB2"] = PB2_state;
  pinState["PB1"] = PB1_state;
  pinState["PB0"] = PB0_state;

  serializeJsonPretty(pinState, Serial);
} // end of readMCPState

/*
 * Test Relay Class
 */

void Test_Relay() {
  Serial.println("FunctionTest:  Relay");
  RELAY1_ON;
  delay(1000);
  RELAY1_OFF;
  delay(1000);

  RELAY2_ON;
  delay(1000);
  RELAY2_OFF;
  delay(1000);

  RELAY3_ON;
  delay(1000);
  RELAY3_OFF;
  delay(1000);

  RELAY4_ON;
  delay(1000);
  RELAY4_OFF;
  delay(1000);

  LED3_ON;
  delay(1000);
  LED3_OFF;
  delay(1000);

  LED2_ON;
  delay(1000);
  LED2_OFF;
  delay(1000);

  LED4G_ON;
  delay(1000);
  LED4G_OFF;
  delay(1000);

  LEDWIFI_ON;
  delay(1000);
  LEDWIFI_OFF;
  delay(1000);
}