const char* ssid     = "itbakery-wifi";
const char* password = "itbakery@9";
const char* hostname = "ESP32_1";

IPAddress ip(192, 168, 1, 200);
IPAddress gateway(192, 168, 1, 1);
IPAddress subnet(255, 255, 255, 0);